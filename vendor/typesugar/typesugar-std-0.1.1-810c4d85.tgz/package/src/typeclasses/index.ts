/**
 * Standard Typeclasses
 *
 * A comprehensive set of typeclasses drawing from the best of:
 * - Haskell (Bounded, Enum, Num, Integral, Fractional, Read, Show)
 * - Scala 3 (Ordering, Numeric, Conversion, CanEqual)
 * - Rust (Default, Clone, Copy, Display, FromStr, Into/From, Iterator)
 * - Kotlin (Comparable, ClosedRange, Iterable, Grouping)
 * - Swift (Codable, Hashable, Identifiable, CustomStringConvertible)
 *
 * All typeclasses follow the @typeclass pattern and support:
 * - Auto-derivation via @derive
 * - Extension methods via the typeclass system
 * - Zero-cost specialization via inlining
 * - Operator overloading via @op JSDoc tags
 */

import { registerInstanceWithMeta } from "@typesugar/macros";

// ============================================================================
// Eq — Haskell Eq, Rust PartialEq/Eq, Scala CanEqual
// Types supporting equality comparison.
// ============================================================================

/**
 * Eq typeclass - equality comparison with operator support.
 *
 * Laws:
 * - Reflexivity: `equals(x, x) === true`
 * - Symmetry: `equals(x, y) === equals(y, x)`
 * - Transitivity: `equals(x, y) && equals(y, z) => equals(x, z)`
 *
 * Operators dispatch via @op JSDoc tags (each method carries both spellings):
 * - `a === b` and `a == b` → `Eq.equals(a, b)`
 * - `a !== b` and `a != b` → `Eq.notEquals(a, b)`
 *
 * Comparisons with `null`/`undefined` (`a == null`) stay native. For reference
 * identity in a file that activated Eq operators, use `Object.is(a, b)`.
 *
 * @typeclass
 */
export interface Eq<A> {
  /**
   * @op ===
   * @op ==
   */
  equals(a: A, b: A): boolean;
  /**
   * @op !==
   * @op !=
   */
  notEquals(a: A, b: A): boolean;
}

/**
 * Eq for numbers. Deliberately JS `===` semantics, because this instance backs
 * the `===` operator rewrite: `equals(NaN, NaN)` is false (so NaN breaks Eq's
 * reflexivity law) and `equals(-0, 0)` is true. Use `ordNumber.equals` for a
 * lawful equivalence in which NaN equals itself. `@typesugar/collections`
 * HashSet/HashMap treat NaN as one key regardless (like native Set/Map).
 */
export const eqNumber: Eq<number> = {
  equals: (a, b) => a === b,
  notEquals: (a, b) => a !== b,
};
registerInstanceWithMeta(
  {
    typeclassName: "Eq",
    forType: "number",
    instanceName: "eqNumber",
    derived: false,
  },
  eqNumber
);

export const eqBigInt: Eq<bigint> = {
  equals: (a, b) => a === b,
  notEquals: (a, b) => a !== b,
};
registerInstanceWithMeta(
  {
    typeclassName: "Eq",
    forType: "bigint",
    instanceName: "eqBigInt",
    derived: false,
  },
  eqBigInt
);

export const eqString: Eq<string> = {
  equals: (a, b) => a === b,
  notEquals: (a, b) => a !== b,
};
registerInstanceWithMeta(
  {
    typeclassName: "Eq",
    forType: "string",
    instanceName: "eqString",
    derived: false,
  },
  eqString
);

export const eqBoolean: Eq<boolean> = {
  equals: (a, b) => a === b,
  notEquals: (a, b) => a !== b,
};
registerInstanceWithMeta(
  {
    typeclassName: "Eq",
    forType: "boolean",
    instanceName: "eqBoolean",
    derived: false,
  },
  eqBoolean
);

export const eqDate: Eq<Date> = {
  equals: (a, b) => a.getTime() === b.getTime(),
  notEquals: (a, b) => a.getTime() !== b.getTime(),
};
registerInstanceWithMeta(
  {
    typeclassName: "Eq",
    forType: "Date",
    instanceName: "eqDate",
    derived: false,
  },
  eqDate
);

/**
 * Create an Eq instance from a custom equality function.
 */
export function makeEq<A>(eq: (a: A, b: A) => boolean): Eq<A> {
  return {
    equals: eq,
    notEquals: (a, b) => !eq(a, b),
  };
}

/**
 * Create an Eq instance by mapping to a comparable value.
 */
export function eqBy<A, B>(f: (a: A) => B, E: Eq<B> = eqStrict()): Eq<A> {
  return {
    equals: (a, b) => E.equals(f(a), f(b)),
    notEquals: (a, b) => E.notEquals(f(a), f(b)),
  };
}

/**
 * Eq using strict equality (===).
 */
export function eqStrict<A>(): Eq<A> {
  return {
    equals: (a, b) => a === b,
    notEquals: (a, b) => a !== b,
  };
}

/**
 * Eq for arrays (element-wise comparison).
 */
export function eqArray<A>(E: Eq<A>): Eq<A[]> {
  return {
    equals: (xs, ys) => {
      if (xs.length !== ys.length) return false;
      return xs.every((x, i) => E.equals(x, ys[i]));
    },
    notEquals: (xs, ys) => {
      if (xs.length !== ys.length) return true;
      return xs.some((x, i) => E.notEquals(x, ys[i]));
    },
  };
}

// ============================================================================
// Hash — Haskell Hashable, Rust Hash, Scala hashCode, Swift Hashable
// Types that can produce a hash value for use in hash-based collections.
// ============================================================================

/**
 * Hash typeclass - types that can be hashed for use in HashMap/HashSet.
 *
 * Law:
 * - Consistency with Eq: `Eq.equals(a, b) => Hash.hash(a) === Hash.hash(b)`
 *   (equal values MUST have equal hashes; unequal values MAY collide)
 *
 * @typeclass
 */
export interface Hash<A> {
  hash(a: A): number;
}

/**
 * Hash for numbers. Consistent with both `eqNumber` and `ordNumber`: `0` and
 * `-0` hash alike, and every NaN hashes to one value. Small integers hash to
 * themselves; other values (fractions, large integers, ±Infinity) hash their
 * decimal string, so they don't all collapse to one bucket.
 */
export const hashNumber: Hash<number> = {
  hash: (a) => {
    if (a !== a) return 0x7fc00000; // NaN
    if (Number.isInteger(a) && a >= -(2 ** 31) && a < 2 ** 31) return a | 0; // -0 -> 0
    return hashString.hash(String(a));
  },
};
registerInstanceWithMeta(
  {
    typeclassName: "Hash",
    forType: "number",
    instanceName: "hashNumber",
    derived: false,
  },
  hashNumber
);

export const hashString: Hash<string> = {
  hash: (a) => {
    let h = 5381;
    for (let i = 0; i < a.length; i++) h = ((h << 5) + h + a.charCodeAt(i)) | 0;
    return h;
  },
};
registerInstanceWithMeta(
  {
    typeclassName: "Hash",
    forType: "string",
    instanceName: "hashString",
    derived: false,
  },
  hashString
);

export const hashBoolean: Hash<boolean> = {
  hash: (a) => (a ? 1 : 0),
};
registerInstanceWithMeta(
  {
    typeclassName: "Hash",
    forType: "boolean",
    instanceName: "hashBoolean",
    derived: false,
  },
  hashBoolean
);

export const hashBigInt: Hash<bigint> = {
  hash: (a) => Number(a & 0x7fffffffn) | 0,
};
registerInstanceWithMeta(
  {
    typeclassName: "Hash",
    forType: "bigint",
    instanceName: "hashBigInt",
    derived: false,
  },
  hashBigInt
);

export const hashDate: Hash<Date> = {
  hash: (a) => a.getTime() | 0,
};
registerInstanceWithMeta(
  {
    typeclassName: "Hash",
    forType: "Date",
    instanceName: "hashDate",
    derived: false,
  },
  hashDate
);

/**
 * Create a Hash instance from a custom hash function.
 */
export function makeHash<A>(hash: (a: A) => number): Hash<A> {
  return { hash };
}

/**
 * Create a Hash instance by mapping to a hashable value.
 */
export function hashBy<A, B>(f: (a: A) => B, H: Hash<B>): Hash<A> {
  return { hash: (a) => H.hash(f(a)) };
}

/**
 * Hash for arrays (combines element hashes).
 */
export function hashArray<A>(H: Hash<A>): Hash<A[]> {
  return {
    hash: (arr) => {
      let h = 0x811c9dc5;
      for (let i = 0; i < arr.length; i++) {
        h ^= H.hash(arr[i]);
        h = (h * 0x01000193) | 0;
      }
      return h;
    },
  };
}

// ============================================================================
// Ord — Haskell Ord, Rust Ord, Scala Ordering
// Types supporting total ordering.
// ============================================================================

/**
 * Ordering result type.
 */
export type Ordering = -1 | 0 | 1;
export const LT: Ordering = -1;
export const EQ_ORD: Ordering = 0;
export const GT: Ordering = 1;

/**
 * Ord typeclass - total ordering with operator support.
 *
 * Laws (in addition to Eq laws):
 * - Antisymmetry: `compare(x, y) <= 0 && compare(y, x) <= 0 => equals(x, y)`
 * - Transitivity: `compare(x, y) <= 0 && compare(y, z) <= 0 => compare(x, z) <= 0`
 * - Totality: `compare(x, y) <= 0 || compare(y, x) <= 0`
 *
 * Operators dispatch via @op JSDoc tags:
 * - `a < b`  → `Ord.lessThan(a, b)`
 * - `a <= b` → `Ord.lessThanOrEqual(a, b)`
 * - `a > b`  → `Ord.greaterThan(a, b)`
 * - `a >= b` → `Ord.greaterThanOrEqual(a, b)`
 *
 * @typeclass
 */
export interface Ord<A> extends Eq<A> {
  compare(a: A, b: A): Ordering;
  /** @op < */
  lessThan(a: A, b: A): boolean;
  /** @op <= */
  lessThanOrEqual(a: A, b: A): boolean;
  /** @op > */
  greaterThan(a: A, b: A): boolean;
  /** @op >= */
  greaterThanOrEqual(a: A, b: A): boolean;
}

/**
 * Total order on numbers: `-0` and `0` compare equal, and NaN sorts after every
 * other number and is equal to itself, so `compare`, `equals` and the comparison
 * methods always agree (JS `<` / `===` do not for NaN). For non-NaN inputs this
 * is exactly `<`, `<=`, `>`, `>=`, `===`. Same semantics as `@typesugar/fp`'s
 * `ordNumber`. (`eqNumber` keeps plain `===` semantics; see there.)
 */
const compareNumber = (a: number, b: number): Ordering => {
  if (a < b) return LT;
  if (a > b) return GT;
  if (a === b) return EQ_ORD;
  // At least one is NaN.
  const an = a !== a;
  const bn = b !== b;
  return an && bn ? EQ_ORD : an ? GT : LT;
};
export const ordNumber: Ord<number> = {
  equals: (a, b) => compareNumber(a, b) === EQ_ORD,
  notEquals: (a, b) => compareNumber(a, b) !== EQ_ORD,
  compare: compareNumber,
  lessThan: (a, b) => compareNumber(a, b) === LT,
  lessThanOrEqual: (a, b) => compareNumber(a, b) !== GT,
  greaterThan: (a, b) => compareNumber(a, b) === GT,
  greaterThanOrEqual: (a, b) => compareNumber(a, b) !== LT,
};
registerInstanceWithMeta(
  {
    typeclassName: "Ord",
    forType: "number",
    instanceName: "ordNumber",
    derived: false,
  },
  ordNumber
);

export const ordBigInt: Ord<bigint> = {
  equals: (a, b) => a === b,
  notEquals: (a, b) => a !== b,
  compare: (a, b) => (a < b ? LT : a > b ? GT : EQ_ORD),
  lessThan: (a, b) => a < b,
  lessThanOrEqual: (a, b) => a <= b,
  greaterThan: (a, b) => a > b,
  greaterThanOrEqual: (a, b) => a >= b,
};
registerInstanceWithMeta(
  {
    typeclassName: "Ord",
    forType: "bigint",
    instanceName: "ordBigInt",
    derived: false,
  },
  ordBigInt
);

export const ordString: Ord<string> = {
  equals: (a, b) => a === b,
  notEquals: (a, b) => a !== b,
  compare: (a, b) => (a < b ? LT : a > b ? GT : EQ_ORD),
  lessThan: (a, b) => a < b,
  lessThanOrEqual: (a, b) => a <= b,
  greaterThan: (a, b) => a > b,
  greaterThanOrEqual: (a, b) => a >= b,
};
registerInstanceWithMeta(
  {
    typeclassName: "Ord",
    forType: "string",
    instanceName: "ordString",
    derived: false,
  },
  ordString
);

export const ordBoolean: Ord<boolean> = {
  equals: (a, b) => a === b,
  notEquals: (a, b) => a !== b,
  compare: (a, b) => (a === b ? EQ_ORD : a ? GT : LT),
  lessThan: (a, b) => !a && b,
  lessThanOrEqual: (a, b) => !a || b,
  greaterThan: (a, b) => a && !b,
  greaterThanOrEqual: (a, b) => a || !b,
};
registerInstanceWithMeta(
  {
    typeclassName: "Ord",
    forType: "boolean",
    instanceName: "ordBoolean",
    derived: false,
  },
  ordBoolean
);

export const ordDate: Ord<Date> = {
  equals: (a, b) => a.getTime() === b.getTime(),
  notEquals: (a, b) => a.getTime() !== b.getTime(),
  compare: (a, b) => {
    const ta = a.getTime();
    const tb = b.getTime();
    return ta < tb ? LT : ta > tb ? GT : EQ_ORD;
  },
  lessThan: (a, b) => a.getTime() < b.getTime(),
  lessThanOrEqual: (a, b) => a.getTime() <= b.getTime(),
  greaterThan: (a, b) => a.getTime() > b.getTime(),
  greaterThanOrEqual: (a, b) => a.getTime() >= b.getTime(),
};
registerInstanceWithMeta(
  {
    typeclassName: "Ord",
    forType: "Date",
    instanceName: "ordDate",
    derived: false,
  },
  ordDate
);

/**
 * Create an Ord instance from a compare function.
 */
export function makeOrd<A>(compare: (a: A, b: A) => Ordering): Ord<A> {
  return {
    equals: (a, b) => compare(a, b) === EQ_ORD,
    notEquals: (a, b) => compare(a, b) !== EQ_ORD,
    compare,
    lessThan: (a, b) => compare(a, b) === LT,
    lessThanOrEqual: (a, b) => compare(a, b) !== GT,
    greaterThan: (a, b) => compare(a, b) === GT,
    greaterThanOrEqual: (a, b) => compare(a, b) !== LT,
  };
}

/**
 * Create an Ord instance by mapping to a comparable value.
 */
export function ordBy<A, B>(f: (a: A) => B, O: Ord<B>): Ord<A> {
  return {
    equals: (a, b) => O.equals(f(a), f(b)),
    notEquals: (a, b) => O.notEquals(f(a), f(b)),
    compare: (a, b) => O.compare(f(a), f(b)),
    lessThan: (a, b) => O.lessThan(f(a), f(b)),
    lessThanOrEqual: (a, b) => O.lessThanOrEqual(f(a), f(b)),
    greaterThan: (a, b) => O.greaterThan(f(a), f(b)),
    greaterThanOrEqual: (a, b) => O.greaterThanOrEqual(f(a), f(b)),
  };
}

/**
 * Reverse an Ord instance.
 */
export function reverseOrd<A>(O: Ord<A>): Ord<A> {
  return {
    equals: O.equals,
    notEquals: O.notEquals,
    compare: (a, b) => O.compare(b, a),
    lessThan: O.greaterThan,
    lessThanOrEqual: O.greaterThanOrEqual,
    greaterThan: O.lessThan,
    greaterThanOrEqual: O.lessThanOrEqual,
  };
}

/**
 * Ord for arrays (lexicographic comparison).
 */
export function ordArray<A>(O: Ord<A>): Ord<A[]> {
  const E = eqArray({ equals: O.equals, notEquals: O.notEquals });
  const compare = (xs: A[], ys: A[]): Ordering => {
    const len = Math.min(xs.length, ys.length);
    for (let i = 0; i < len; i++) {
      const cmp = O.compare(xs[i], ys[i]);
      if (cmp !== EQ_ORD) return cmp;
    }
    return xs.length < ys.length ? LT : xs.length > ys.length ? GT : EQ_ORD;
  };
  return {
    equals: E.equals,
    notEquals: E.notEquals,
    compare,
    lessThan: (xs, ys) => compare(xs, ys) === LT,
    lessThanOrEqual: (xs, ys) => compare(xs, ys) !== GT,
    greaterThan: (xs, ys) => compare(xs, ys) === GT,
    greaterThanOrEqual: (xs, ys) => compare(xs, ys) !== LT,
  };
}

// ============================================================================
// Semigroup — Haskell Semigroup, Scala cats Semigroup
// Types with an associative binary operation.
// ============================================================================

/**
 * Semigroup typeclass - types with an associative combine operation.
 *
 * Law:
 * - Associativity: `combine(combine(a, b), c) === combine(a, combine(b, c))`
 *
 * Operators dispatch via @op JSDoc tags:
 * - `a + b` → `Semigroup.combine(a, b)` (for additive semigroups)
 *
 * @typeclass
 */
export interface Semigroup<A> {
  /** @op + */
  combine(a: A, b: A): A;
}

export const semigroupString: Semigroup<string> = {
  combine: (a, b) => a + b,
};
registerInstanceWithMeta(
  {
    typeclassName: "Semigroup",
    forType: "string",
    instanceName: "semigroupString",
    derived: false,
  },
  semigroupString
);

export const semigroupNumber: Semigroup<number> = {
  combine: (a, b) => a + b,
};
registerInstanceWithMeta(
  {
    typeclassName: "Semigroup",
    forType: "number",
    instanceName: "semigroupNumber",
    derived: false,
  },
  semigroupNumber
);

export const semigroupBigInt: Semigroup<bigint> = {
  combine: (a, b) => a + b,
};
registerInstanceWithMeta(
  {
    typeclassName: "Semigroup",
    forType: "bigint",
    instanceName: "semigroupBigInt",
    derived: false,
  },
  semigroupBigInt
);

/**
 * Semigroup for arrays (concatenation).
 */
export function semigroupArray<A>(): Semigroup<A[]> {
  return {
    combine: (a, b) => [...a, ...b],
  };
}

// ============================================================================
// Monoid — Haskell Monoid, Scala cats Monoid
// Semigroup with an identity element.
// ============================================================================

/**
 * Monoid typeclass - Semigroup with an identity element.
 *
 * Laws (in addition to Semigroup laws):
 * - Left identity: `combine(empty(), a) === a`
 * - Right identity: `combine(a, empty()) === a`
 *
 * Operators dispatch via @op JSDoc tags:
 * - `a + b` → `Monoid.combine(a, b)` (`@op` tags are not inherited, so the
 *   inherited `combine` is restated here for the monoid/ops marker)
 *
 * @typeclass
 */
export interface Monoid<A> extends Semigroup<A> {
  /** @op + */
  combine(a: A, b: A): A;
  empty(): A;
}

export const monoidString: Monoid<string> = {
  combine: (a, b) => a + b,
  empty: () => "",
};
registerInstanceWithMeta(
  {
    typeclassName: "Monoid",
    forType: "string",
    instanceName: "monoidString",
    derived: false,
  },
  monoidString
);

export const monoidNumber: Monoid<number> = {
  combine: (a, b) => a + b,
  empty: () => 0,
};
registerInstanceWithMeta(
  {
    typeclassName: "Monoid",
    forType: "number",
    instanceName: "monoidNumber",
    derived: false,
  },
  monoidNumber
);

export const monoidBigInt: Monoid<bigint> = {
  combine: (a, b) => a + b,
  empty: () => 0n,
};
registerInstanceWithMeta(
  {
    typeclassName: "Monoid",
    forType: "bigint",
    instanceName: "monoidBigInt",
    derived: false,
  },
  monoidBigInt
);

/**
 * Monoid for arrays (concatenation with empty array).
 */
export function monoidArray<A>(): Monoid<A[]> {
  return {
    combine: (a, b) => [...a, ...b],
    empty: () => [],
  };
}

// Re-export FlatMap typeclass (HKT-based, for let:/yield: macro)
export * from "./flatmap.js";

// Re-export ParCombine typeclass + runtime instances (for par:/yield: macro).
// Only the `typescript`-free runtime surface is re-exported here so the runtime
// `.` entry stays typescript-free (PEP-050 Case-1). The compile-time builders +
// registry live in `./par-combine.js`, loaded by the transformer via `./macros`.
export * from "./par-combine-instances.js";

// Re-export generic numeric operations
export * from "./numeric-ops.js";

// Re-export Destructure typeclass (for pattern matching, PEP-008)
export * from "./destructure.js";

// ============================================================================
// Bounded — Haskell Bounded, Rust: implicit via type, Scala: not built-in
// Types with a minimum and maximum value.
// ============================================================================

/**
 * Bounded typeclass - types with minimum and maximum values.
 * Instances are resolved from scope (PEP-052) for summon<Bounded<T>>().
 */
export interface Bounded<A> {
  minBound(): A;
  maxBound(): A;
}

/**
 * Bounds by convention: the safe-integer range, not the true extremes of
 * `number` (which are -Infinity/Infinity; `Number.MAX_VALUE` is the largest
 * finite value). Values outside these bounds exist.
 */
export const boundedNumber: Bounded<number> = {
  minBound: () => Number.MIN_SAFE_INTEGER,
  maxBound: () => Number.MAX_SAFE_INTEGER,
};
registerInstanceWithMeta(
  {
    typeclassName: "Bounded",
    forType: "number",
    instanceName: "boundedNumber",
    derived: false,
  },
  boundedNumber
);

/**
 * `bigint` is unbounded: there is no true min or max. This instance is a
 * convention that mirrors `boundedNumber` (±`Number.MAX_SAFE_INTEGER`) so code
 * that needs *some* Bounded<bigint> has one; bigints beyond these "bounds" are
 * valid values and `x <= maxBound()` does not hold for them.
 */
export const boundedBigInt: Bounded<bigint> = {
  minBound: () => BigInt("-9007199254740991"),
  maxBound: () => BigInt("9007199254740991"),
};
registerInstanceWithMeta(
  {
    typeclassName: "Bounded",
    forType: "bigint",
    instanceName: "boundedBigInt",
    derived: false,
  },
  boundedBigInt
);

export const boundedBoolean: Bounded<boolean> = {
  minBound: () => false,
  maxBound: () => true,
};
registerInstanceWithMeta(
  {
    typeclassName: "Bounded",
    forType: "boolean",
    instanceName: "boundedBoolean",
    derived: false,
  },
  boundedBoolean
);

/**
 * Strings have a least element (`""`) but no greatest one: any string can be
 * extended to a larger one. `maxBound` is a convention — 256 copies of U+FFFF,
 * which is greater than every string of up to 256 code units but less than
 * longer strings that start with it.
 */
export const boundedString: Bounded<string> = {
  minBound: () => "",
  maxBound: () => "\uFFFF".repeat(256),
};
registerInstanceWithMeta(
  {
    typeclassName: "Bounded",
    forType: "string",
    instanceName: "boundedString",
    derived: false,
  },
  boundedString
);

// ============================================================================
// Enum — Haskell Enum, Rust: not built-in, Scala: Enumeration
// Types with successors and predecessors, convertible to/from integers.
// ============================================================================

/**
 * Enum typeclass - types with successors/predecessors, convertible to/from integers.
 * Instances are resolved from scope (PEP-052) for summon<Enum<T>>().
 */
export interface Enum<A> {
  succ(a: A): A;
  pred(a: A): A;
  toEnum(n: number): A;
  fromEnum(a: A): number;
}

export const enumNumber: Enum<number> = {
  succ: (a) => a + 1,
  pred: (a) => a - 1,
  toEnum: (n) => n,
  fromEnum: (a) => a,
};
registerInstanceWithMeta(
  {
    typeclassName: "Enum",
    forType: "number",
    instanceName: "enumNumber",
    derived: false,
  },
  enumNumber
);

export const enumBoolean: Enum<boolean> = {
  succ: (a) => !a,
  pred: (a) => !a,
  toEnum: (n) => n !== 0,
  fromEnum: (a) => (a ? 1 : 0),
};
registerInstanceWithMeta(
  {
    typeclassName: "Enum",
    forType: "boolean",
    instanceName: "enumBoolean",
    derived: false,
  },
  enumBoolean
);

export const enumString: Enum<string> = {
  succ: (a) =>
    a.length === 0 ? "a" : a.slice(0, -1) + String.fromCharCode(a.charCodeAt(a.length - 1) + 1),
  pred: (a) =>
    a.length === 0 ? "" : a.slice(0, -1) + String.fromCharCode(a.charCodeAt(a.length - 1) - 1),
  toEnum: (n) => String.fromCharCode(n),
  fromEnum: (a) => (a.length > 0 ? a.charCodeAt(0) : 0),
};
registerInstanceWithMeta(
  {
    typeclassName: "Enum",
    forType: "string",
    instanceName: "enumString",
    derived: false,
  },
  enumString
);

// ============================================================================
// Numeric — Haskell Num, Scala Numeric, Kotlin: Number
// Types supporting basic arithmetic.
// ============================================================================

/**
 * Numeric typeclass - types supporting basic arithmetic operations.
 *
 * This is the Ring abstraction: add, sub, mul with identity elements.
 * Instances are resolved from scope (PEP-052) for summon<Numeric<T>>().
 *
 * Operators dispatch via @op JSDoc tags:
 * - `a + b` → `Numeric.add(a, b)`
 * - `a - b` → `Numeric.sub(a, b)`
 * - `a * b` → `Numeric.mul(a, b)`
 *
 * `/` is deliberately NOT tagged here: it belongs to `Fractional` (true
 * division) and `Integral` (floor division), and a type with both a Numeric
 * and a Fractional instance would otherwise be an ambiguous-operator error.
 *
 * @typeclass
 */
export interface Numeric<A> {
  /** @op + */
  add(a: A, b: A): A;
  /** @op - */
  sub(a: A, b: A): A;
  /** @op * */
  mul(a: A, b: A): A;
  div(a: A, b: A): A;
  pow(a: A, b: A): A;
  negate(a: A): A;
  abs(a: A): A;
  signum(a: A): A;
  fromNumber(n: number): A;
  toNumber(a: A): number;
  zero(): A;
  one(): A;
}

export const numericNumber: Numeric<number> = {
  add: (a, b) => a + b,
  sub: (a, b) => a - b,
  mul: (a, b) => a * b,
  div: (a, b) => a / b,
  pow: (a, b) => a ** b,
  negate: (a) => -a,
  abs: (a) => Math.abs(a),
  signum: (a) => Math.sign(a) as number,
  fromNumber: (n) => n,
  toNumber: (a) => a,
  zero: () => 0,
  one: () => 1,
};
registerInstanceWithMeta(
  {
    typeclassName: "Numeric",
    forType: "number",
    instanceName: "numericNumber",
    derived: false,
  },
  numericNumber
);

export const numericBigInt: Numeric<bigint> = {
  add: (a, b) => a + b,
  sub: (a, b) => a - b,
  mul: (a, b) => a * b,
  div: (a, b) => a / b,
  pow: (a, b) => a ** b,
  negate: (a) => -a,
  abs: (a) => (a < 0n ? -a : a),
  signum: (a) => (a < 0n ? -1n : a > 0n ? 1n : 0n),
  fromNumber: (n) => BigInt(Math.trunc(n)),
  toNumber: (a) => Number(a),
  zero: () => 0n,
  one: () => 1n,
};
registerInstanceWithMeta(
  {
    typeclassName: "Numeric",
    forType: "bigint",
    instanceName: "numericBigInt",
    derived: false,
  },
  numericBigInt
);

// ============================================================================
// Integral — Haskell Integral
// Integer-like types supporting division and modulo.
// ============================================================================

/**
 * Integral typeclass - integer-like types supporting division and modulo.
 *
 * This is the Euclidean Ring abstraction.
 *
 * Operators dispatch via @op JSDoc tags (for integer types):
 * - `a / b` → `Integral.div(a, b)` (floor division)
 * - `a % b` → `Integral.mod(a, b)` (modulo)
 *
 * @typeclass
 */
export interface Integral<A> {
  /** @op / */
  div(a: A, b: A): A;
  /** @op % */
  mod(a: A, b: A): A;
  divMod(a: A, b: A): [A, A];
  quot(a: A, b: A): A;
  rem(a: A, b: A): A;
  toInteger(a: A): bigint;
}

export const integralNumber: Integral<number> = {
  div: (a, b) => Math.floor(a / b),
  mod: (a, b) => ((a % b) + b) % b,
  divMod: (a, b) => {
    const d = Math.floor(a / b);
    return [d, a - d * b];
  },
  quot: (a, b) => Math.trunc(a / b),
  rem: (a, b) => a % b,
  toInteger: (a) => BigInt(Math.trunc(a)),
};
registerInstanceWithMeta(
  {
    typeclassName: "Integral",
    forType: "number",
    instanceName: "integralNumber",
    derived: false,
  },
  integralNumber
);

export const integralBigInt: Integral<bigint> = {
  div: (a, b) => {
    const d = a / b;
    return a < 0n !== b < 0n && a % b !== 0n ? d - 1n : d;
  },
  mod: (a, b) => ((a % b) + b) % b,
  divMod: (a, b) => {
    const d = integralBigInt.div(a, b);
    return [d, a - d * b];
  },
  quot: (a, b) => a / b,
  rem: (a, b) => a % b,
  toInteger: (a) => a,
};
registerInstanceWithMeta(
  {
    typeclassName: "Integral",
    forType: "bigint",
    instanceName: "integralBigInt",
    derived: false,
  },
  integralBigInt
);

// ============================================================================
// Fractional — Haskell Fractional
// Types supporting real division.
// ============================================================================

/**
 * Fractional typeclass - types supporting real division.
 *
 * This is the Field abstraction (for fractional/floating types).
 *
 * Operators dispatch via @op JSDoc tags (for fractional types):
 * - `a / b` → `Fractional.div(a, b)` (true division)
 *
 * @typeclass
 */
export interface Fractional<A> {
  /** @op / */
  div(a: A, b: A): A;
  recip(a: A): A;
  fromRational(num: number, den: number): A;
}

export const fractionalNumber: Fractional<number> = {
  div: (a, b) => a / b,
  recip: (a) => 1 / a,
  fromRational: (num, den) => num / den,
};
registerInstanceWithMeta(
  {
    typeclassName: "Fractional",
    forType: "number",
    instanceName: "fractionalNumber",
    derived: false,
  },
  fractionalNumber
);

// ============================================================================
// Floating — Haskell Floating
// Types supporting transcendental functions.
// ============================================================================

export interface Floating<A> {
  pi(): A;
  exp(a: A): A;
  log(a: A): A;
  sqrt(a: A): A;
  pow(a: A, b: A): A;
  sin(a: A): A;
  cos(a: A): A;
  tan(a: A): A;
  asin(a: A): A;
  acos(a: A): A;
  atan(a: A): A;
  atan2(a: A, b: A): A;
  sinh(a: A): A;
  cosh(a: A): A;
  tanh(a: A): A;
}

export const floatingNumber: Floating<number> = {
  pi: () => Math.PI,
  exp: Math.exp,
  log: Math.log,
  sqrt: Math.sqrt,
  pow: Math.pow,
  sin: Math.sin,
  cos: Math.cos,
  tan: Math.tan,
  asin: Math.asin,
  acos: Math.acos,
  atan: Math.atan,
  atan2: Math.atan2,
  sinh: Math.sinh,
  cosh: Math.cosh,
  tanh: Math.tanh,
};
registerInstanceWithMeta(
  {
    typeclassName: "Floating",
    forType: "number",
    instanceName: "floatingNumber",
    derived: false,
  },
  floatingNumber
);

// ============================================================================
// Group — Haskell Group, Scala cats-kernel Group
// Monoid with an inverse operation. Completes the algebraic chain:
// Semigroup → Monoid → Group
// ============================================================================

/**
 * Group typeclass - a Monoid with an inverse operation.
 *
 * Laws:
 * - All Monoid laws (associativity, identity)
 * - Left inverse: `combine(invert(a), a) === empty()`
 * - Right inverse: `combine(a, invert(a)) === empty()`
 *
 * @example
 * ```typescript
 * const additiveGroup: Group<number> = {
 *   empty: () => 0,
 *   combine: (a, b) => a + b,
 *   invert: (a) => -a,
 * };
 * ```
 *
 * @typeclass
 */
export interface Group<A> {
  /** The identity element */
  empty(): A;
  /**
   * Associative binary operation
   * @op +
   */
  combine(a: A, b: A): A;
  /** Inverse operation: combine(invert(a), a) === empty() */
  invert(a: A): A;
}

/** Additive group for numbers (identity: 0, operation: +, inverse: negation) */
export const groupNumber: Group<number> = {
  empty: () => 0,
  combine: (a, b) => a + b,
  invert: (a) => -a,
};
registerInstanceWithMeta(
  {
    typeclassName: "Group",
    forType: "number",
    instanceName: "groupNumber",
    derived: false,
  },
  groupNumber
);

/** Additive group for bigint */
export const groupBigInt: Group<bigint> = {
  empty: () => 0n,
  combine: (a, b) => a + b,
  invert: (a) => -a,
};
registerInstanceWithMeta(
  {
    typeclassName: "Group",
    forType: "bigint",
    instanceName: "groupBigInt",
    derived: false,
  },
  groupBigInt
);

// ============================================================================
// Clone — Rust Clone, Haskell: not built-in (pure values), Scala: not built-in
// Types that can produce a deep copy of themselves.
// ============================================================================

/**
 * Clone typeclass - deep copy of a value.
 *
 * Law:
 * - Identity: `Eq.equals(clone(a), a) === true` (when Eq is available)
 * - Independence: mutating `clone(a)` does not affect `a`
 *
 * @typeclass
 */
export interface Clone<A> {
  clone(a: A): A;
}

export const cloneNumber: Clone<number> = {
  clone: (a) => a,
};
registerInstanceWithMeta(
  {
    typeclassName: "Clone",
    forType: "number",
    instanceName: "cloneNumber",
    derived: false,
  },
  cloneNumber
);

export const cloneString: Clone<string> = {
  clone: (a) => a,
};
registerInstanceWithMeta(
  {
    typeclassName: "Clone",
    forType: "string",
    instanceName: "cloneString",
    derived: false,
  },
  cloneString
);

export const cloneBoolean: Clone<boolean> = {
  clone: (a) => a,
};
registerInstanceWithMeta(
  {
    typeclassName: "Clone",
    forType: "boolean",
    instanceName: "cloneBoolean",
    derived: false,
  },
  cloneBoolean
);

export const cloneBigInt: Clone<bigint> = {
  clone: (a) => a,
};
registerInstanceWithMeta(
  {
    typeclassName: "Clone",
    forType: "bigint",
    instanceName: "cloneBigInt",
    derived: false,
  },
  cloneBigInt
);

export const cloneDate: Clone<Date> = {
  clone: (a) => new Date(a.getTime()),
};
registerInstanceWithMeta(
  {
    typeclassName: "Clone",
    forType: "Date",
    instanceName: "cloneDate",
    derived: false,
  },
  cloneDate
);

/**
 * Create a Clone instance from a custom clone function.
 */
export function makeClone<A>(cloneFn: (a: A) => A): Clone<A> {
  return { clone: cloneFn };
}

/**
 * Clone for arrays (element-wise deep clone).
 */
export function cloneArray<A>(C: Clone<A>): Clone<A[]> {
  return { clone: (arr) => arr.map((x) => C.clone(x)) };
}

// ============================================================================
// Debug — Rust Debug, Haskell Show (developer-facing), Swift debugDescription
// Developer-facing string representation for debugging/logging.
// ============================================================================

/**
 * Debug typeclass - developer-facing string representation.
 *
 * Unlike a human-readable display string, Debug produces unambiguous output
 * suitable for logging and debugging. Strings are quoted, types are
 * annotated, etc.
 *
 * @typeclass
 */
export interface Debug<A> {
  debug(a: A): string;
}

export const debugNumber: Debug<number> = {
  debug: (a) => String(a),
};
registerInstanceWithMeta(
  {
    typeclassName: "Debug",
    forType: "number",
    instanceName: "debugNumber",
    derived: false,
  },
  debugNumber
);

export const debugString: Debug<string> = {
  debug: (a) => JSON.stringify(a),
};
registerInstanceWithMeta(
  {
    typeclassName: "Debug",
    forType: "string",
    instanceName: "debugString",
    derived: false,
  },
  debugString
);

export const debugBoolean: Debug<boolean> = {
  debug: (a) => String(a),
};
registerInstanceWithMeta(
  {
    typeclassName: "Debug",
    forType: "boolean",
    instanceName: "debugBoolean",
    derived: false,
  },
  debugBoolean
);

export const debugBigInt: Debug<bigint> = {
  debug: (a) => `${a}n`,
};
registerInstanceWithMeta(
  {
    typeclassName: "Debug",
    forType: "bigint",
    instanceName: "debugBigInt",
    derived: false,
  },
  debugBigInt
);

export const debugDate: Debug<Date> = {
  debug: (a) => `Date(${JSON.stringify(a.toISOString())})`,
};
registerInstanceWithMeta(
  {
    typeclassName: "Debug",
    forType: "Date",
    instanceName: "debugDate",
    derived: false,
  },
  debugDate
);

/**
 * Create a Debug instance from a custom debug function.
 */
export function makeDebug<A>(debugFn: (a: A) => string): Debug<A> {
  return { debug: debugFn };
}

/**
 * Debug for arrays.
 */
export function debugArray<A>(D: Debug<A>): Debug<A[]> {
  return { debug: (arr) => `[${arr.map((x) => D.debug(x)).join(", ")}]` };
}

// ============================================================================
// Json — Scala circe Codec, Rust serde, Haskell aeson ToJSON/FromJSON
// Types that can be serialized to/from JSON.
// ============================================================================

/**
 * Json typeclass - bidirectional JSON serialization.
 *
 * Laws:
 * - Round-trip: `fromJson(toJson(a))` deeply equals `a`
 *
 * @typeclass
 */
export interface Json<A> {
  toJson(a: A): unknown;
  fromJson(json: unknown): A;
}

export const jsonNumber: Json<number> = {
  toJson: (a) => a,
  fromJson: (json) => json as number,
};
registerInstanceWithMeta(
  {
    typeclassName: "Json",
    forType: "number",
    instanceName: "jsonNumber",
    derived: false,
  },
  jsonNumber
);

export const jsonString: Json<string> = {
  toJson: (a) => a,
  fromJson: (json) => json as string,
};
registerInstanceWithMeta(
  {
    typeclassName: "Json",
    forType: "string",
    instanceName: "jsonString",
    derived: false,
  },
  jsonString
);

export const jsonBoolean: Json<boolean> = {
  toJson: (a) => a,
  fromJson: (json) => json as boolean,
};
registerInstanceWithMeta(
  {
    typeclassName: "Json",
    forType: "boolean",
    instanceName: "jsonBoolean",
    derived: false,
  },
  jsonBoolean
);

export const jsonBigInt: Json<bigint> = {
  toJson: (a) => String(a),
  fromJson: (json) => BigInt(json as string),
};
registerInstanceWithMeta(
  {
    typeclassName: "Json",
    forType: "bigint",
    instanceName: "jsonBigInt",
    derived: false,
  },
  jsonBigInt
);

export const jsonDate: Json<Date> = {
  toJson: (a) => a.toISOString(),
  fromJson: (json) => new Date(json as string),
};
registerInstanceWithMeta(
  {
    typeclassName: "Json",
    forType: "Date",
    instanceName: "jsonDate",
    derived: false,
  },
  jsonDate
);

/**
 * Create a Json instance from custom serialization functions.
 */
export function makeJson<A>(toJson: (a: A) => unknown, fromJson: (json: unknown) => A): Json<A> {
  return { toJson, fromJson };
}

/**
 * Json for arrays (element-wise serialization).
 */
export function jsonArray<A>(J: Json<A>): Json<A[]> {
  return {
    toJson: (arr) => arr.map((x) => J.toJson(x)),
    fromJson: (json) => (json as unknown[]).map((x) => J.fromJson(x)),
  };
}
